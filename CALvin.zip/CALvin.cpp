#include <iostream>
using namespace std;


int main() {
	int nbook=1000,tbook=500,ebook=1500,pencil=200,
	pen=900,eraser=100, sharpener=50,mathset=100,opaper=100,
	A4sheet=600,ruler=200,scissors=400,bags=50,notepad=100,calculator=100,marker=50,duster=50,bm=20,
	option,option2,attempts=0; char O,X;
	
	cout<<"WELCOME TO THE MANAGERIAL OPTION OF CALVIN'S STATIONARY... YOU ARE ALLOWED TO SEEK OR MODIFY INFORMATION ABOUT"<<endl;
	cout<<"___________________________________________ITEMS IN STOCK______________________________________________________"<<endl;
	
	cout<<"BELOW ARE THE INDEXSES ATTACHED TO THE ITEMS IN STOCK"<<endl;
	cout<<"1-NOTEBOOKS"<<endl;
	cout<<"2-TEXTBOOKS"<<endl;
	cout<<"3-EXERCISE BOOKS"<<endl;
	cout<<"4-PENCILS"<<endl;
	cout<<"5-PENS"<<endl;
	cout<<"6-ERASERS"<<endl;
	cout<<"7-SHARPENERS"<<endl;
	cout<<"8-MATHSETS"<<endl;
	cout<<"9-OFFICIAL PAPERS"<<endl;
	cout<<"10-A4 PAPERS"<<endl;
	cout<<"11-RULERS"<<endl;
	cout<<"12-SCISSORS"<<endl;
	cout<<"13-BAGS"<<endl;
	cout<<"14-NOTEPADS"<<endl;
	cout<<"15-CALCULATORS"<<endl;
	cout<<"16-MARKERS"<<endl;
	cout<<"17-DUSTERS"<<endl;
	cout<<"18-BOOK MARKS"<<endl;
	cout<<"____________________________________________________________________________________________________________________"<<endl;
	
	cout<<"A-NUMBER OF A PARTICULAR ITEM IN STOCK?...ENTER YOUR DESIRED OPTION FROM THE ABOVE(1-18)"<<endl;
	cout<<"B-UPDATE THE ITEMS IN STOCK (ADD OR UPDATE ITEMS THAT HAVE BEEN REMOVED FROM THE INVENTORY)?"<<endl;
	cout<<"C-VIEW THE PRICES OF ITEMS IN STOCK"<<endl;
	cout<<"D-Exit Program"<<endl;
		star:
		cout<<"Enter A,B OR C to start or D to exit the program"<<endl;
		cin>>O;
		

	//VIEWING NUMBER OF ITEMS
	 if(O=='A'||O=='a'){

		cout<<"Enter any option from 1 to 18 from the above of the item of choice to know its quantity in the inventory"<<endl;
		cin>>option;
		if(option==1){
		cout<<"There are "<<nbook<< " notebooks in stock"<<endl;
	    goto star;
		}
		if(option==2){
		cout<<"There are "<<tbook<<" textbooks in stock"<<endl;
		goto star;;
		}
		if(option==3){
		cout<<"There are "<<ebook<<" exercise books in stock"<<endl;
		goto star;;
		}
		if(option==4){
		cout<<"There are "<<pencil<<" pencils in stock"<<endl;
		goto star;
		}
		if(option==5){
		cout<<"There are "<<pen<<" pens in stock"<<endl;
		goto star;;
		}
		if(option==6){
		cout<<"There are "<<eraser<<" erasers in stock"<<endl;
		goto star;
		}
		if(option==7){
		cout<<"There are "<<sharpener<<" sharpeners in stock"<<endl;
		goto star;
		}
		if(option==8){
		cout<<"There are "<<mathset<<" mathsets in stock"<<endl;
		goto star;
		}
		if(option==9){
		cout<<"There are "<<opaper<<" official papers in stock"<<endl;
		goto star;
		}
		if(option==10){
		cout<<"There are "<<A4sheet<<" A4 sheets in stock"<<endl;
		goto star;
		}
		if(option==11){
		cout<<"There are "<<ruler<<" rulers in stock"<<endl;
		goto star;
		}
		if(option==12){
		cout<<"There are "<<scissors<<" scissors in stock"<<endl;
		goto star;
		}
		if(option==13){
		cout<<"There are "<<bags<<" bags in stock"<<endl;
		goto star;
		}
		if(option==14){
		cout<<"There are "<<notepad<<" notepads in stock"<<endl;
		goto star;
		}
		if(option==15){
		cout<<"There are "<<calculator<<" calculators in stock"<<endl;
		goto star;
		}
		if(option==16){
		cout<<"There are "<<marker<<" markers in stock"<<endl;
		goto star;
		}
		if(option==17){
		cout<<"There are "<<duster<<" dusters in stock"<<endl;
		goto star;
		}
		if(option==18){
		cout<<"There are "<<bm<<" book-marks in stock"<<endl;
		goto star;
		}
		else{
			cout<<"Invalid Option"<<endl;
			goto star;
		}
	}
	//UPDATING ITEMS IN STOCK
	else if(O=='B'||O=='b'){
		n:
		cout<<"Select Your Desired Item from the above to Update(1-18)"<<endl;
		cin>>option2;
		if(option2==1){
			int new_nbook;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_nbook;
			nbook=new_nbook+nbook;
			cout<<"The amount of Notebooks in Your inventory is now "<<nbook<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			s:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_nbook;
			if(new_nbook>nbook){
			cout<<"Invalid amount of notebooks"<<endl;
			goto s;
			}
			
			else if(new_nbook==nbook){
			cout<<"Out of stock inventory needs to be filled with new notebooks"<<endl;
			
			}
		
			else{
				nbook=nbook-new_nbook;
			cout<<"The amount of notebooks in your inventory is now "<<nbook<<endl;}
			goto star;
			
			
		}
		
		}
	if(option2==2){
			int new_tbook;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_tbook;
			tbook=new_tbook+tbook;
			cout<<"The amount of Textbooks in Your inventory is now "<<tbook<<endl;
			
		}
		else if(X=='D'||X=='d'){
			q:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_tbook;
			if(new_tbook>tbook){
			cout<<"Invalid amount of textbooks"<<endl;
			goto q;
			}
			
			else if(new_tbook==tbook){
			cout<<"Out of stock inventory needs to be filled with new textbooks"<<endl;
				
			}
		
			else{
				tbook=tbook-new_tbook;
			cout<<"The amount of textbooks in your inventory is now "<<tbook<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==3){
			int new_ebook;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_ebook;
			ebook=new_ebook+ebook;
			cout<<"The amount of Exercise books in Your inventory is now "<<ebook<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			r:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_ebook;
			if(new_ebook>ebook){
			cout<<"Invalid amount of exercise books"<<endl;
			goto r;
			}
			
			else if(new_ebook==ebook){
			cout<<"Out of stock inventory needs to be filled with new exercise books"<<endl;
			
			}
		
			else{
				ebook=ebook-new_ebook;
			cout<<"The amount of exercise books in your inventory is now "<<ebook<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==4){
			int new_pencil;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_pencil;
			pencil=new_pencil+pencil;
			cout<<"The amount of Pencils in Your inventory is now "<<ebook<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			p:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_pencil;
			if(new_pencil>pencil){
			cout<<"Invalid amount of pencils"<<endl;
			goto p;
			}
			
			else if(new_pencil==pencil){
			cout<<"Out of stock inventory needs to be filled with new pencils"<<endl;
				
			}
		
			else{
				pencil=pencil-new_pencil;
			cout<<"The amount of pencils in your inventory is now "<<pencil<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==5){
			int new_pen;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_pen;
			pen=new_pen+pen;
			cout<<"The amount of Pens in Your inventory is now "<<pen<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			d:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_pen;
			if(new_pen>pen){
			cout<<"Invalid amount of pens"<<endl;
			goto d;
			}
			
			else if(new_pen==pen){
			cout<<"Out of stock inventory needs to be filled with new pens"<<endl;
				
			}
		
			else{
				pen=pen-new_pen;
			cout<<"The amount of pens in your inventory is now "<<pen<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==6){
			int new_eraser;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_eraser;
			eraser=new_eraser+eraser;
			cout<<"The amount of Erasers in Your inventory is now "<<eraser<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			e:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_eraser;
			if(new_eraser>eraser){
			cout<<"Invalid amount of erasers"<<endl;
			goto e;
			}
			
			else if(new_eraser==eraser){
			cout<<"Out of stock inventory needs to be filled with new erasers"<<endl;
			
			}
		
			else{
				eraser=eraser-new_eraser;
			cout<<"The amount of eraser in your inventory is now "<<eraser<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==7){
			int new_sharpener;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_sharpener;
			sharpener=new_sharpener+sharpener;
			cout<<"The amount of Sharpeners in Your inventory is now "<<sharpener<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			w:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_sharpener;
			if(new_sharpener>sharpener){
			cout<<"Invalid amount of sharpener"<<endl;
			goto w;
			}
			
			else if(new_sharpener==sharpener){
			cout<<"Out of stock inventory needs to be filled with new sharpeners"<<endl;
			
			}
		
			else{
				sharpener=sharpener-new_sharpener;
			cout<<"The amount of sharpeners in your inventory is now "<<sharpener<<endl;}
		    goto star;
			
			
		}
		
		}
		if(option2==8){
			int new_mathset;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_mathset;
			mathset=new_mathset+mathset;
			cout<<"The amount of Mathsets in Your inventory is now "<<mathset<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			k:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_mathset;
			if(new_mathset>mathset){
			cout<<"Invalid amount of mathsets"<<endl;
			goto w;
			}
			
			else if(new_mathset==mathset){
			cout<<"Out of stock inventory needs to be filled with new mathsets"<<endl;
				
			}
		
			else{
				mathset=mathset-new_mathset;
			cout<<"The amount of mathsets in your inventory is now "<<mathset<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==9){
			int new_opaper;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_opaper;
			opaper=new_opaper+opaper;
			cout<<"The amount of Official Papers in Your inventory is now "<<opaper<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			m:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_opaper;
			if(new_opaper>opaper){
			cout<<"Invalid amount of official papers"<<endl;
			goto m;
			}
			
			else if(new_opaper==opaper){
			cout<<"Out of stock inventory needs to be filled with new Official Papers"<<endl;
				
			}
		
			else{
				opaper=opaper-new_opaper;
			cout<<"The amount of official papers in your inventory is now "<<opaper<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==10){
			int new_A4sheet;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_A4sheet;
			A4sheet=new_A4sheet+A4sheet;
			cout<<"The amount of A4 sheets in Your inventory is now "<<A4sheet<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			y:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_A4sheet;
			if(new_A4sheet>A4sheet){
			cout<<"Invalid amount of A4 sheets"<<endl;
			goto y;
			}
			
			else if(new_A4sheet==A4sheet){
			cout<<"Out of stock inventory needs to be filled with new A4 sheets"<<endl;
				
			}
		
			else{
				A4sheet=A4sheet-new_A4sheet;
			cout<<"The amount of A4 sheets in your inventory is now "<<A4sheet<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==11){
			int new_ruler;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_ruler;
			ruler=new_ruler+ruler;
			cout<<"The amount of Rulers in Your inventory is now "<<ruler<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			c:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_ruler;
			if(new_ruler>ruler){
			cout<<"Invalid amount of Rulers"<<endl;
			goto c;
			}
			
			else if(new_ruler==ruler){
			cout<<"Out of stock inventory needs to be filled with new Rulers"<<endl;
			
			}
		
			else{
				ruler=ruler-new_ruler;
			cout<<"The amount of Rulers in your inventory is now "<<ruler<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==12){
			int new_scissors;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_scissors;
			scissors=new_scissors+scissors;
			cout<<"The amount of Scissors in Your inventory is now "<<scissors<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			z:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_scissors;
			if(new_scissors>scissors){
			cout<<"Invalid amount of Scissors"<<endl;
			goto z;
			}
			
			else if(new_scissors==scissors){
			cout<<"Out of stock inventory needs to be filled with new Scissors"<<endl;
			
			}
		
			else{
			scissors=scissors-new_scissors;
			cout<<"The amount of Scissors in your inventory is now "<<scissors<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==13){
			int new_bags;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_bags;
			bags=new_bags+bags;
			cout<<"The amount of Bags in Your inventory is now "<<bags<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			f:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_bags;
			if(new_bags>bags){
			cout<<"Invalid amount of Bags"<<endl;
			goto f;
			}
			
			else if(new_bags==bags){
			cout<<"Out of stock inventory needs to be filled with new bags"<<endl;
				
			}
		
			else{
			bags=bags-new_bags;
			cout<<"The amount of Bags in your inventory is now "<<bags<<endl;}
			goto star;
			
			
		}
		
		}	
		if(option2==14){
			int new_notepad;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_notepad;
			notepad=new_notepad+notepad;
			cout<<"The amount of Notepad in Your inventory is now "<<notepad<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			t:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_notepad;
			if(new_notepad>notepad){
			cout<<"Invalid amount of Notepad"<<endl;
			goto t;
			}
			
			else if(new_notepad==notepad){
			cout<<"Out of stock inventory needs to be filled with new notepad"<<endl;
			
			}
		
			else{
			notepad=notepad-new_notepad;
			cout<<"The amount of Notepad in your inventory is now "<<notepad<<endl;}
			goto star;
			
			
		}
		
		}	
		if(option2==15){
			int new_calculator;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_calculator;
			calculator=new_calculator+calculator;
			cout<<"The amount of Calculators in Your inventory is now "<<calculator<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			g:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_calculator;
			if(new_calculator>calculator){
			cout<<"Invalid amount of calculators"<<endl;
			goto g;
			}
			
			else if(new_calculator==calculator){
			cout<<"Out of stock inventory needs to be filled with new calculators"<<endl;
				
			}
		
			else{
			calculator=calculator-new_calculator;
			cout<<"The amount of Calculator in your inventory is now "<<calculator<<endl;}
			goto star;
			
			
		}
		
		}
		if(option2==16){
			int new_marker;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_marker;
			marker=new_marker+marker;
			cout<<"The amount of Markers in Your inventory is now "<<marker<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			h:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_marker;
			if(new_marker>marker){
			cout<<"Invalid amount of Markers"<<endl;
			goto h;
			}
			
			else if(new_marker==marker){
			cout<<"Out of stock inventory needs to be filled with new markers"<<endl;
				
			}
		
			else{
			marker=marker-new_marker;
			cout<<"The amount of Marker in your inventory is now "<<marker<<endl;}
			goto star;
			
			
		}
		
		}	
		if(option2==17){
			int new_duster;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_duster;
			duster=new_duster+duster;
			cout<<"The amount of Dusters in Your inventory is now "<<duster<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			l:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_duster;
			if(new_duster>duster){
			cout<<"Invalid amount of Dusters"<<endl;
			goto l;
			}
			
			else if(new_duster==duster){
			cout<<"Out of stock inventory needs to be filled with new dusters"<<endl;
				
			}
		
			else{
			duster=duster-new_duster;
			cout<<"The amount of Duster in your inventory is now "<<duster<<endl;}
			goto star;
			
			
		}
		
		}	
		if(option2==18){
			int new_bm;
			cout<<"Do you want to add or delete this item?(Select'A'to add/Select 'D'to delete or update items that have been removed from the inventory)"<<endl;
			cin>>X;
		if(X=='A'||X=='a'){
			cout<<"Enter amount to be added"<<endl;
			cin>>new_bm;
			bm=new_bm+bm;
			cout<<"The amount of Book marks in Your inventory is now "<<bm<<endl;
			goto star;
		}
		else if(X=='D'||X=='d'){
			u:
			cout<<"Enter number of items removed from the inventory"<<endl;
			cin>>new_bm;
			if(new_bm>bm){
			cout<<"Invalid amount of Book marks"<<endl;
			goto u;
			}
			
			else if(new_bm==bm){
			cout<<"Out of stock inventory needs to be filled with new Book marks"<<endl;
				
			}
		
			else{
			bm=bm-new_bm;
			cout<<"The amount of Book marks in your inventory is now "<<bm<<endl;}
			goto star;
			
			
		}
		
		}																																																																																																					
	}
	//VIEWING PRICES OF ITEMS
		
	if(O=='C'||O=='c'){
		
cout<<"NOTEBOOK--Ghc 20.00"<<endl;
	cout<<"TEXTBOOKS--Ghc 50.00"<<endl;
	cout<<"EXERCISE BOOKS--Ghc 2.00"<<endl;
	cout<<"PENCILS--Ghc1.00"<<endl;
	cout<<"PENS--Ghc 1.05p"<<endl;
	cout<<"ERASERS--0.5p"<<endl;
	cout<<"SHARPENERS--0.5p"<<endl;
	cout<<"MATHSETS--Ghc 10.00"<<endl;
	cout<<"OFFICIAL PAPERS--0.2p"<<endl;
	cout<<"A4 PAPERS--Ghc 2.00"<<endl;
	cout<<"RULERS--Ghc 1.50p"<<endl;
	cout<<"SCISSORS--Ghc 3.00"<<endl;
	cout<<"BAGS-- Ghc 100"<<endl;
	cout<<"NOTEPADS-- Ghc 10.00"<<endl;
	cout<<"CALCULATORS-- Ghc 120.00"<<endl;
	cout<<"MARKERS-- Ghc 3.00"<<endl;
	cout<<"DUSTERS-- Ghc 5.00"<<endl;
	cout<<"BOOK MARKS-- Ghc 1.00"<<endl;
	goto star;	
	}	
		
	if(O=='D'||O=='d'){
		cout<<"Exiting Program..."<<endl;
	
		
		}	
		
		
		
		
		
		
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	return 0;
}
